export class bookInfo
{
  book_name: string;
  author_name: string;
  genre: string;
  year_pub: number;
  picture: string;
}