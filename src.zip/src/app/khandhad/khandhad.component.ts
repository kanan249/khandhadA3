import { Component, OnInit } from '@angular/core';
import { book1 } from '../myBooks';
import { bookInfo } from '../bookInfo';

@Component({
  selector: 'app-khandhad',
  templateUrl: './khandhad.component.html',
  styleUrls: ['./khandhad.component.css']
})
export class KhandhadComponent implements OnInit {
  currentbook= book1;
  book_data : bookInfo;
  
  constructor() { }

  ngOnInit() {
    this.c_book(0);

  }
  c_book(i) {
    this.book_data = {
      book_name: this.currentbook[i].book_name,
      author_name: this.currentbook[i].author_name,
      genre: this.currentbook[i].genre,
      year_pub: this.currentbook[i].year_pub,
      picture: this.currentbook[i].picture
    }
  }
}
