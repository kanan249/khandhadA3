export class khandhad {
  sname: string;
  slogin: string;
  sid: number;
  scampus: string;
  assignmentTitle: string;
}