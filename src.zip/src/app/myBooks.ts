import { bookInfo } from '../app/bookInfo';

import { from } from 'rxjs';

export const book1: bookInfo[] =
[
  { book_name: "The Da Vinci Code", author_name: "Dan Brown",
  genre: "Mystery", year_pub: 2001, picture: 'assets/images/code.jpg'},
  
  { book_name: "Angels and Demons", author_name: "Dan Brown",
    genre: "Mystery", year_pub: 2002, picture: 'assets/images/A&D.jpg' },
  
  { book_name: 'Memories of midnight', author_name: 'Sidney Sheldon',
    genre: 'Thriller', year_pub: 2003, picture: 'assets/images/memories.jpg' },
  
  { book_name: 'if tomorrow comes', author_name: 'Sidney Sheldon',
    genre: 'Thriller', year_pub: 2001, picture: 'assets/images/tomorrow.jpg' }
]