import { Component, OnInit } from '@angular/core';
import { khandhad } from '../khandhad';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  bio: khandhad = {
    sname: "Kanan Khandhadia",
    sid: 991488344,
    scampus: "Davis",
    assignmentTitle: "Assignment 3",
    slogin: "khandhad"
  }
  constructor() { }

  ngOnInit() {
  }

}
